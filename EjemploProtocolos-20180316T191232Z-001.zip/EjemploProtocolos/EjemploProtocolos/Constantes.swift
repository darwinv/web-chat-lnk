//
//  Constantes.swift
//  EjemploProtocolos
//
//  Created by Christian Quicano on 10/26/17.
//  Copyright © 2017 Christian Quicano. All rights reserved.
//

import Foundation

let kTelefono = "telefono"
let kStatus = "status"
